<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
    // Catch-all route for Vue.js
//Route::get('/{any}', function () {
//    return view('welcome'); // Ensure 'app.blade.php' loads your Vue app
//})->where('any', '.*');


Route::prefix('auth')->group(function () {
    Route::get('google',[LoginController::class,'redirectToGoogle']);
    Route::get('google/callback', [LoginController::class, 'googleLogin']);
});
