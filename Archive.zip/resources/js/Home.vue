<script setup>

</script>

<template>
    <h1>home</h1>
</template>

<style scoped>

</style>
